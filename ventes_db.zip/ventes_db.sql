-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 07 mai 2021 à 19:42
-- Version du serveur :  10.4.17-MariaDB
-- Version de PHP : 7.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ventes_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `id` int(11) NOT NULL,
  `nom` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`id`, `nom`) VALUES
(3, 'aliments'),
(4, 'boissons gazeuzes');

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

CREATE TABLE `produit` (
  `id_produit` int(11) NOT NULL,
  `code_produit` varchar(10) NOT NULL,
  `designation` varchar(30) NOT NULL,
  `qte_stock` int(11) NOT NULL,
  `date_peremption` date DEFAULT NULL COMMENT 'on peut ne pas avoir de date de péremption',
  `prix` double NOT NULL,
  `idcategorie` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `produit`
--

INSERT INTO `produit` (`id_produit`, `code_produit`, `designation`, `qte_stock`, `date_peremption`, `prix`, `idcategorie`) VALUES
(70, 'pizza2', 'bolognaise pizza', 12, '2019-10-07', 5000, 3),
(65, 'beer1', 'castel 65cl', 50, '2020-10-10', 600, 4),
(66, 'beer2', '\"33\" export 65cl', 50, '2020-10-10', 650, 3),
(67, 'beer3', 'Kadji 65cl', 50, '2020-10-10', 600, 4),
(68, 'beer4', 'Magnan 65cl', 50, '2020-10-10', 600, 4),
(69, 'pizza001', 'pizza all america', 10, '2019-12-07', 5000, 3),
(59, 'jus001', 'top ananas 35 cl', 30, '2020-01-01', 400, 3),
(62, 'jus002', 'top pamplemousse 35 cl', 100, '2020-01-01', 350, 4);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `Identifiant` varchar(30) NOT NULL,
  `mot_de_passe` varchar(30) NOT NULL,
  `nom` varchar(30) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `addresse` varchar(30) NOT NULL,
  `role` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `Identifiant`, `mot_de_passe`, `nom`, `prenom`, `addresse`, `role`) VALUES
(1, 'Yvan', '1', '', '', '', 'vendeur'),
(3, 'a', 'a', 'a', 'a', 'a', 'boss'),
(4, 'Kamto', 'Kamto1234', 'Kamto', 'Dylan', 'sdgsdf', 'vendeur');

-- --------------------------------------------------------

--
-- Structure de la table `vendeur`
--

CREATE TABLE `vendeur` (
  `num_vendeur` int(11) NOT NULL,
  `nom_vendeur` varchar(30) NOT NULL,
  `login` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `vendeur`
--

INSERT INTO `vendeur` (`num_vendeur`, `nom_vendeur`, `login`, `pass`) VALUES
(1, 'Yalakou', 'Ymerveille', 'merveille'),
(2, 'Mandjock', 'Mleslie', 'leslie'),
(3, 'Djéon', 'Djstelle', 'stell1234'),
(4, 'Patrick', 'Patrick', '12345');

-- --------------------------------------------------------

--
-- Structure de la table `vente`
--

CREATE TABLE `vente` (
  `id` int(11) NOT NULL,
  `num_vendeur` int(11) NOT NULL,
  `code_produit` varchar(10) NOT NULL,
  `qte_vendue` int(11) NOT NULL,
  `dates_ventes` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `produit`
--
ALTER TABLE `produit`
  ADD PRIMARY KEY (`id_produit`),
  ADD UNIQUE KEY `code_produit` (`code_produit`),
  ADD KEY `fk_produit_cat` (`idcategorie`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mot_de_passe` (`mot_de_passe`);

--
-- Index pour la table `vendeur`
--
ALTER TABLE `vendeur`
  ADD PRIMARY KEY (`num_vendeur`);

--
-- Index pour la table `vente`
--
ALTER TABLE `vente`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_vente_vente` (`num_vendeur`),
  ADD KEY `fk_vente_produit` (`code_produit`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `categorie`
--
ALTER TABLE `categorie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `produit`
--
ALTER TABLE `produit`
  MODIFY `id_produit` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `vendeur`
--
ALTER TABLE `vendeur`
  MODIFY `num_vendeur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `vente`
--
ALTER TABLE `vente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
